public class Hole extends Button {
    int row;
    int col;
    String color=null ;
    boolean activated;

    public Hole(String type, boolean selected, int row, int col, boolean activated) {
        super(type, selected);
        this.row = row;
        this.col = col;
        this.activated = false;
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }

    public boolean getActivated() {
        return activated;
    }

    public void setActivated(boolean activated) {
        this.activated = activated;
    }

}
