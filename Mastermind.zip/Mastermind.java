import javax.swing.*;
import java.awt.*;

public class Mastermind {

    private static JPanel buttonPanel;
    static int numTour = 0;

    public static int getNumTour() {
        return numTour;
    }

    public static JPanel getbuttonPanel() {
            return buttonPanel;
        }
    public static void main(String[] args) {
        JFrame frame = new JFrame("Button Grid Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(416, 832);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);


        buttonPanel = new JPanel(new GridLayout(16, 7));
        buttonPanel.setPreferredSize(new Dimension(400, 800));

        GridBagConstraints constraints = new GridBagConstraints();

        Button.createButtons(buttonPanel, constraints);

        // Ajoute le JPanel contenant la grille de boutons au cadre
        frame.add(buttonPanel);

        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation(dim.width/2 - frame.getWidth()/2, dim.height/2 - frame.getHeight()/2 + 10);

        frame.setVisible(true);

    }

}
