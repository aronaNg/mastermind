import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Button {
    String type;
    boolean selected;

    public Button(String type, boolean selected) {
        this.type = type;
        this.selected = false;
    }

    public void settype(String type) {
        this.type = type;
    }

    public String gettype() {
        return type;
    }

    public void setselected(boolean selected) {
        this.selected = selected;
    }

    public boolean getselected() {
        return selected;
    }

    private static List<Button> buttons = new ArrayList<>();
    private static List<Pawn> pawns = new ArrayList<>();
    private static List<Hole> holes = new ArrayList<>();

    private static int selectedHole = 0;
    private static String selectedPawn = null;

    String[] types = {"Pawn", "Hole", "Validate", "Decoration"};

    static ImageIcon I0R0B = new ImageIcon("Image\\0R0B.gif");
    static ImageIcon I1B = new ImageIcon("Image\\1B.gif");
    static ImageIcon I1R = new ImageIcon("Image\\1R.gif");
    static ImageIcon I1R1B = new ImageIcon("Image\\1R1B.gif");
    static ImageIcon I1R2B = new ImageIcon("Image\\1R2B.gif");
    static ImageIcon I1R3B = new ImageIcon("Image\\1R3B.gif");
    static ImageIcon I2B = new ImageIcon("Image\\2B.gif");
    static ImageIcon I2R = new ImageIcon("Image\\2R.gif");
    static ImageIcon I2R1B = new ImageIcon("Image\\2R1B.gif");
    static ImageIcon I2R2B = new ImageIcon("Image\\2R2B.gif");
    static ImageIcon I3B = new ImageIcon("Image\\3B.gif");
    static ImageIcon I3R = new ImageIcon("Image\\3R.gif");
    static ImageIcon I3R1B = new ImageIcon("Image\\3R1B.gif");
    static ImageIcon I4B = new ImageIcon("Image\\4B.gif");
    static ImageIcon I4R = new ImageIcon("Image\\4R.gif");
    static ImageIcon IEntreBoutons = new ImageIcon("Image\\Entre_Couleurs&Valide.gif");
    static ImageIcon IL1C1 = new ImageIcon("Image\\L1C1.gif");
    static ImageIcon IL1C2 = new ImageIcon("Image\\L1C2.gif");
    static ImageIcon IL1C3 = new ImageIcon("Image\\L1C3.gif");
    static ImageIcon IL1C5 = new ImageIcon("Image\\L1C5.gif");
    static ImageIcon IL1C6 = new ImageIcon("Image\\L1C6.gif");
    static ImageIcon IL1C7 = new ImageIcon("Image\\L1C7.gif");
    static ImageIcon IL1C8 = new ImageIcon("Image\\L1C8.gif");
    static ImageIcon IL2C1 = new ImageIcon("Image\\L2C1.gif");
    static ImageIcon IL2C6 = new ImageIcon("Image\\L2C6.gif");
    static ImageIcon IL2C8 = new ImageIcon("Image\\L2C8.gif");
    static ImageIcon IL3C1 = new ImageIcon("Image\\L3C1.gif");
    static ImageIcon IL3C6 = new ImageIcon("Image\\L3C6.gif");
    static ImageIcon IL3C8 = new ImageIcon("Image\\L3C8.gif");
    static ImageIcon IL9C1 = new ImageIcon("Image\\L9C1.gif");
    static ImageIcon IL9C6 = new ImageIcon("Image\\L9C6.gif");
    static ImageIcon IL10C1 = new ImageIcon("Image\\L10C1.gif");
    static ImageIcon IL10C2 = new ImageIcon("Image\\L10C2.gif");
    static ImageIcon IL10C3 = new ImageIcon("Image\\L10C3.gif");
    static ImageIcon IL10C5 = new ImageIcon("Image\\L10C5.gif");
    static ImageIcon IL10C6 = new ImageIcon("Image\\L10C6.gif");
    static ImageIcon IL10C7 = new ImageIcon("Image\\L10C7.gif");
    static ImageIcon IL10C8 = new ImageIcon("Image\\L10C8.gif");
    static ImageIcon IL11C1 = new ImageIcon("Image\\L11C1.gif");
    static ImageIcon IL11C8 = new ImageIcon("Image\\L11C8.gif");
    static ImageIcon IL12C1 = new ImageIcon("Image\\L12C1.gif");
    static ImageIcon IL12C2 = new ImageIcon("Image\\L12C2.gif");
    static ImageIcon IL12C3 = new ImageIcon("Image\\L12C3.gif");
    static ImageIcon IL12C7 = new ImageIcon("Image\\L12C7.gif");
    static ImageIcon IL12C8 = new ImageIcon("Image\\L12C8.gif");
    static ImageIcon IPBS = new ImageIcon("Image\\Pion_Bleu_Selection.gif");
    static ImageIcon IPB = new ImageIcon("Image\\Pion_Bleu.gif");
    static ImageIcon IPJS = new ImageIcon("Image\\Pion_Jaune_Selection.gif");
    static ImageIcon IPJ = new ImageIcon("Image\\Pion_Jaune.gif");
    static ImageIcon IPRS = new ImageIcon("Image\\Pion_Rouge_Selection.gif");
    static ImageIcon IPR = new ImageIcon("Image\\Pion_Rouge.gif");
    static ImageIcon IPVS = new ImageIcon("Image\\Pion_Vert_Selection.gif");
    static ImageIcon IPV = new ImageIcon("Image\\Pion_Vert.gif");
    static ImageIcon ITS = new ImageIcon("Image\\Trou_Selection.gif");
    static ImageIcon IT = new ImageIcon("Image\\Trou.gif");
    static ImageIcon IBValideClic = new ImageIcon("Image\\Valide_Clic.gif");
    static ImageIcon IBValide = new ImageIcon("Image\\Valide.gif");
        

    public static ImageIcon getScaledImageIcon(ImageIcon originalIcon) {
        int width = 50;
        int height = 50;
        Image originalImage = originalIcon.getImage();
        Image scaledImage = originalImage.getScaledInstance(width, height, java.awt.Image.SCALE_SMOOTH);
        return new ImageIcon(scaledImage);
    }

    public static void changeIconButton(int buttonNumber, JPanel buttonPanel, ImageIcon image) {

        Component[] components = buttonPanel.getComponents();

        // Get a specific button
        JButton specificButton = (JButton) components[buttonNumber-1];

        // Modify the button
        ImageIcon scaledIcon = getScaledImageIcon(image);
        specificButton.setIcon(scaledIcon);
        specificButton.revalidate();
        specificButton.repaint();
    }

    static ImageIcon[] imageIcons = {I0R0B,I1B,I1R,I1R1B,I1R2B,I1R3B,I2B,I2R,I2R1B,I2R2B, /*10*/I3B,I3R,I3R1B,I4B,I4R,IEntreBoutons,IL1C1,IL1C2,IL1C3,IL1C5, /*20*/IL1C6,IL1C7,IL1C8,IL2C1,IL2C6,IL2C8,IL3C1,IL3C6,IL3C8,IL9C1, /*30*/IL9C6,IL10C1,IL10C2,IL10C3,IL10C5,IL10C6,IL10C8,IL11C1,IL11C8,IL12C1, /*40*/IL12C2,IL12C3,IL12C7,IL12C8,IPBS,IPB,IPJS,IPJ,IPRS,IPR, /*50*/IPVS,IPV,ITS,IT,IBValideClic,IBValide};


    static java.awt.event.ActionListener buttonActionListener = new java.awt.event.ActionListener() {
        @Override
        public void actionPerformed(java.awt.event.ActionEvent e) {
            String actionCommand = e.getActionCommand();
            System.out.println("Clicked: " + actionCommand);
            String numberString = actionCommand.replace("Button ", "");
            int buttonNumber = Integer.parseInt(numberString);
            buttonManager(buttonNumber, Mastermind.getbuttonPanel());
        }
    };

    static public void buttonManager(int buttonNumber, JPanel buttonPanel) {
        int numTour = Mastermind.getNumTour();
        if( 8*(12-numTour) +1 < buttonNumber && buttonNumber < 8*(12-numTour) +6){
            int holeNumber = buttonNumber - (8*(12-numTour)+1);
            Hole hole = holes.get(4-holeNumber + 4*numTour);
            if (hole.selected == true){
                hole.selected = false;
                selectedHole = 0;
                changeIconButton(buttonNumber, buttonPanel, imageIcons[53]);
            }
            else if (selectedHole != 0){
                int holeNumberBis = selectedHole - (8*(12-numTour)+1);
                Hole holeBis = holes.get(4-holeNumberBis + 4*numTour);
                holeBis.selected = false;
                changeIconButton(selectedHole, buttonPanel, imageIcons[53]);
                hole.selected = true;
                changeIconButton(buttonNumber, buttonPanel, imageIcons[52]);
                selectedHole = buttonNumber;
            }
            //else if(){}
            //
            //
            else{
                hole.selected = true;
                selectedHole = buttonNumber;
                changeIconButton(buttonNumber, buttonPanel, imageIcons[52]);
            }
        }
    }

    static void createButtons(JPanel buttonPanel, GridBagConstraints constraints) {
        int adaptateur;
        for (int row = 0; row < 16; row++) {
            for (int col = 0; col < 8; col++) {
                JButton buttonFrame;
                adaptateur = 0;
                ImageIcon image;
                if(col==6 && 0<row && row<13){
                    image = imageIcons[0];
                    Button button = new Button("Decoration", false);
                    buttons.add(button);
                }
                else if(row==0)
                {
                    if(col>2)
                        adaptateur = -1;
                    image = imageIcons[16 + col + adaptateur];
                    Button button = new Button("Decoration", false);
                    buttons.add(button);
                }
                else if(col==0){
                    Button button = new Button("Decoration", false);
                    buttons.add(button);
                    if(row==1)
                        image = IL2C1;
                    else if(1<row && row<12)
                        image = IL3C1;
                    else if(row==12)
                        image = IL9C1;
                    else if(row==13)
                        image = IL10C1;
                    else if(row==14)
                        image = IL11C1;
                    else
                        image = IL12C1;
                }
                else if(col==5 && row<13){
                    Button button = new Button("Decoration", false);
                    buttons.add(button);
                    if(row==1)
                        image=IL2C6;
                    else if(1<row && row<12)
                        image=IL3C6;
                    else
                        image=IL9C6;
                }
                else if(col==7 && row!=13){
                    Button button = new Button("Decoration", false);
                    buttons.add(button);
                    if(row==1)
                        image=IL2C8;
                    else if(1<row && row<13)
                        image=IL3C8;
                    else if(row==14)
                        image=IL11C8;
                    else
                        image=IL12C8;
                }
                else if(row==13){
                    Button button = new Button("Decoration", false);
                    buttons.add(button);
                    if(col==1)
                        image=IL10C2;
                    else if(col==2 || col==3)
                        image=IL10C3;
                    else if(col==4)
                        image=IL10C5;
                    else if(col==5)
                        image=IL10C6;
                    else if(col==6)
                        image=IL10C7;
                    else
                        image=IL10C8;
                }
                else if(row==14){
                    if(col==1){
                        Pawn pawn = new Pawn("Pawn", false, "Yellow");
                        pawns.add(pawn);
                        image=IPJ;}
                    else if(col==2){
                        Pawn pawn = new Pawn("Pawn", false, "Red");
                        pawns.add(pawn);
                        image=IPR;}
                    else if(col==3){
                        Pawn pawn = new Pawn("Pawn", false, "Green");
                        pawns.add(pawn);
                        image=IPV;}
                    else if(col==4){
                        Pawn pawn = new Pawn("Pawn", false, "Blue");
                        pawns.add(pawn);
                        image=IPB;}
                    else if(col==5){
                        image=IEntreBoutons;
                        Button button = new Button("Decoration", false);
                        buttons.add(button);}
                    else{
                        Button button = new Button("Validate", false);
                        buttons.add(button);
                        image=IBValide;}
                }
                else if(row==15){
                    Button button = new Button("Decoration", false);
                    buttons.add(button);
                    if(col==1)
                        image=IL12C2;
                    else if(col==6)
                        image=IL12C2;
                    else
                        image=IL12C3;
                }        
                else{
                    Hole hole = new Hole("Hole", false, 13-row, col, false);
                    holes.add(0, hole);
                    image = imageIcons[53];}


                ImageIcon scaledIcon = getScaledImageIcon(image);
                buttonFrame = new JButton(scaledIcon);
                buttonFrame.setActionCommand("Button " + (row * 8 + col + 1));
                buttonFrame.addActionListener(buttonActionListener);


                if(col==6 && row==14)
                    buttonFrame.setPressedIcon( getScaledImageIcon(IBValideClic));
                buttonFrame.setBorderPainted(false); 
                constraints.gridx = col;
                constraints.gridy = row;
                buttonPanel.add(buttonFrame, constraints);
            }
        }
        for(int i=0; i<buttons.size(); i++){
            Button button = buttons.get(i);
            System.out.println("Button : " + button.gettype() );
        }

        Pawn pawn;
        for(int i=0; i<pawns.size(); i++){
            pawn = pawns.get(i);
            System.out.println("Pawn : " + pawn.gettype() + ", " + pawn.getColor() );
        }
        
        for(int i=0; i<holes.size(); i++){
            Hole hole = holes.get(i);
            System.out.println("Hole : " + hole.gettype() + ", " + hole.getRow() + "." + hole.getCol() );
        }
    }
}