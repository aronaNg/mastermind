public class Pawn extends Button {
    String color;

    public Pawn(String type, boolean selected, String color) {
        super(type, selected);
        this.color = color;
    }

    public String getColor() {
        return color;
    }

    public boolean getSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
}
